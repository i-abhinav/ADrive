<?php

namespace App\Providers;
use Illuminate\Support\ServiceProvider;
use Validator;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Bootstrap any application services.
     *
     * @return void
     */
    public function boot()
    {        
         Validator::extend('alpha_tap', function($attribute, $value, $parameters, $validator) {
              if (! is_string($value) && ! is_numeric($value)) {
                return false;
            }
             return preg_match('/^[a-zA-Z0-9-\'_.&\s]+$/u', $value);
        });

        Validator::extend('alpha_bracket', function($attribute, $value, $parameters, $validator) {
              if (! is_string($value) && ! is_numeric($value)) {
                return false;
            }
            //Dot(.)’, Apostrophe(‘), Dash (-),Underscore (_), Ampersand (&), Space ( ), Brackets ( () )
             return preg_match('/^[a-zA-Z0-9-\'_.&\(\)\s]+$/u', $value);
        });

     Validator::extend('alpha_spl', function($attribute, $value, $parameters, $validator) {
              if (! is_string($value) && ! is_numeric($value)) {    
                return false;
            }
             return preg_match('/^[a-zA-Z0-9- \'_.&\(\)@#\s]+$/u', $value);
        });
        //new for forward dot
          Validator::extend('alpha_spl_extra', function($attribute, $value, $parameters, $validator) {
              if (! is_string($value) && ! is_numeric($value)) {    
                return false;
            }
             return preg_match('/^[a-zA-Z0-9- \'._@#\s]+$/u', $value);
        });
          //new for forward slash
            Validator::extend('alpha_spl_extra2', function($attribute, $value, $parameters, $validator) {
              if (! is_string($value) && ! is_numeric($value)) {    
                return false;
            }

             return preg_match('/^[a-zA-Z0-9- \'_@#\s\\/]+$/u', $value);
        });

         Validator::extend('tap_email', function($attribute, $value, $parameters, $validator) {
           return preg_match("/[a-z0-9!#$%&'*+\/=?^_`{|}~-]+(?:\.[a-z0-9!#$%&'*+\/=?^_`{|}~-]+)*@(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z](?:[a-z]*[a-z]){1,}?/u", $value);
            });
           Validator::extend('alpha_space', function($attribute, $value, $parameters, $validator) {
              if (! is_string($value) && ! is_numeric($value)) {
                return false;
            }
             return preg_match('/^[a-zA-Z0-9 ]+$/u', $value);
        });
       Validator::extend('non_decimal', function($attribute, $value, $parameters, $validator) {
              if (! is_string($value) && ! is_numeric($value)) {
                return false;
            }
             return preg_match('/^[\d]*$/', $value);
        });
    }
    /**
     * Register any application services.
     *
     * @return void
     */
    public function register()
    {
        //
    }
}
